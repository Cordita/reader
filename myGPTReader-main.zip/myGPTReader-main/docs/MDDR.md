# Midjourney Driven Design Record

## Logo

Prompt: `a logo for an octopus robot who can read the web pages, simple, vector, Psychedelic Art --no text realistic details`

https://discord.com/channels/662267976984297473/981697635591290970/1090043690166272000

https://discord.com/channels/662267976984297473/981697635591290970/1090044581963382924

https://discord.com/channels/662267976984297473/981697635591290970/1090045469419388928

https://discord.com/channels/662267976984297473/981697635591290970/1090045641369059340

![](https://cdn.discordapp.com/attachments/981697635591290970/1090046333227900969/zFish_a_logo_for_an_octopus_robot_who_can_read_the_web_pages_si_6f065791-5641-4a16-b06d-5c04f82a83d6.png)

Prompt: `a logo for an octopus robot who can read the web pages, simple, vector, cartoon style, on a white background only --no text realistic details`

https://discord.com/channels/662267976984297473/981697635591290970/1090046995458175058

Prompt: `a logo for an octopus robot who can read the web pages, simple, vector, Psychedelic Art on a white background only --no text realistic details`

https://discord.com/channels/662267976984297473/981697635591290970/1090047315491954738

Prompt: `a logo for an octopus robot who can read the web pages, simple, vector, The Matrix style on a white background only --no text realistic details`

https://discord.com/channels/662267976984297473/981697635591290970/1090047861103800330

a logo for an robot who can read the web pages, simple, vector, The Matrix style on a white background only --no text realistic details

https://discord.com/channels/662267976984297473/981697635591290970/1090048376533434409

Prompt: `a logo for an robot who can read the web pages, simple, vector, De Stijl--no text realistic details`

https://discord.com/channels/662267976984297473/981697635591290970/1090048848086454413

https://discord.com/channels/662267976984297473/981697635591290970/1090049019608322178

https://discord.com/channels/662267976984297473/981697635591290970/1090049146355990600

https://discord.com/channels/662267976984297473/981697635591290970/1090049422915813490

Prompt: `a logo for an robot who can read the web pages, simple, vector, De Stijl on a white background only --no text realistic details`

https://discord.com/channels/662267976984297473/981697635591290970/1090049706563997826

Prompt: `a logo for an robot who is reading the web page, simple, vector, De Stijl on a white background only --no text realistic details`

https://discord.com/channels/662267976984297473/981697635591290970/1090050630204272740

https://discord.com/channels/662267976984297473/981697635591290970/1090050961592029184

https://discord.com/channels/662267976984297473/981697635591290970/1090051194816307221

https://discord.com/channels/662267976984297473/981697635591290970/1090051201925648485

![](https://cdn.discordapp.com/attachments/981697635591290970/1090051770455171162/zFish_a_logo_for_an_robot_who_is_reading_the_web_page_simple_ve_a5e699ff-5e4f-43cc-8dbb-bfe21c7d6365.png)

![](https://cdn.discordapp.com/attachments/981697635591290970/1090051855008157807/zFish_a_logo_for_an_robot_who_is_reading_the_web_page_simple_ve_f564472e-950b-49fd-951a-495203d283ea.png)

Prompt: `a logo for an octopus robot who can read the web pages, simple, vector, Psychedelic Art, on a white background only --no text realistic details`

https://discord.com/channels/662267976984297473/981697635591290970/1090053529739206766

https://discord.com/channels/662267976984297473/981697635591290970/1090053697796591656

https://discord.com/channels/662267976984297473/981697635591290970/1090053846363021373

https://discord.com/channels/662267976984297473/981697635591290970/1090054425105678448

![](https://cdn.discordapp.com/attachments/981697635591290970/1090054424933703680/zFish_a_logo_for_an_octopus_robot_who_can_read_the_web_pages_si_39086aeb-a830-4384-a140-f3b654842ddc.png)

