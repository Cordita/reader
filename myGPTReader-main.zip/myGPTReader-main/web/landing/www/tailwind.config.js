module.exports = {
  content: ['./src/**/*.js'],
  theme: {
    extend: {},
  },
  plugins: [],
}
